# MAJOR BOT

## LINK BOT: [Register Here](https://t.me/major/start?startapp=6057140648)
## TUTORIAL IN GROUP : [Join Here](https://t.me/sansxgroup)

## Features
- Auto Claim Bot
- Auto Clear Task
- Auto Play Game