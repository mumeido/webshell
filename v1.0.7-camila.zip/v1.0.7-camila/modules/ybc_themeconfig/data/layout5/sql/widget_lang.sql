INSERT INTO `_DB_PREFIX_ybc_widget_widget_lang` VALUES('14','_ID_LANG_','Tesimonials','<h3>What our happy customers say</h3>
<div id=\"box-tesimonial\">
<div class=\"slider\">
<div class=\"content-tesimonial\">
<p>Lorem ipsum dolor sit amet, consectetur Lorem ipsum dolor sit amet, consectetur adipiscing elit. Integer nec odio. Praesent adipiscing elit. Integer nec odio. Praesent</p>
<a href=\"#\">Diamond Gate</a></div>
</div>
<div class=\"slider\">
<div class=\"content-tesimonial\">
<p>Lorem ipsum dolor sit amet, consectetur Lorem ipsum dolor sit amet, consectetur adipiscing elit. Integer nec odio. Praesent adipiscing elit. Integer nec odio. Praesent</p>
<a href=\"#\">Diamond Gate</a></div>
</div>
<div class=\"slider\">
<div class=\"content-tesimonial\">
<p>Lorem ipsum dolor sit amet, consectetur Lorem ipsum dolor sit amet, consectetur adipiscing elit. Integer nec odio. Praesent adipiscing elit. Integer nec odio. Praesent</p>
<a href=\"#\">Diamond Gate</a></div>
</div>
<div class=\"slider\">
<div class=\"content-tesimonial\">
<p>Lorem ipsum dolor sit amet, consectetur Lorem ipsum dolor sit amet, consectetur adipiscing elit. Integer nec odio. Praesent adipiscing elit. Integer nec odio. Praesent</p>
<a href=\"#\">Diamond Gate</a></div>
</div>
<div class=\"slider\">
<div class=\"content-tesimonial\">
<p>Lorem ipsum dolor sit amet, consectetur Lorem ipsum dolor sit amet, consectetur adipiscing elit. Integer nec odio. Praesent adipiscing elit. Integer nec odio. Praesent</p>
<a href=\"#\">Diamond Gate</a></div>
</div>
</div>');
INSERT INTO `_DB_PREFIX_ybc_widget_widget_lang` VALUES('19','_ID_LANG_','Men’s accessories','');
INSERT INTO `_DB_PREFIX_ybc_widget_widget_lang` VALUES('21','_ID_LANG_','FREE SHIPPING WORLDWIDE','');
INSERT INTO `_DB_PREFIX_ybc_widget_widget_lang` VALUES('22','_ID_LANG_','unlimited customer support','');
INSERT INTO `_DB_PREFIX_ybc_widget_widget_lang` VALUES('23','_ID_LANG_','Free return and exchange','');
INSERT INTO `_DB_PREFIX_ybc_widget_widget_lang` VALUES('35','_ID_LANG_','luxury jewellery','');
INSERT INTO `_DB_PREFIX_ybc_widget_widget_lang` VALUES('36','_ID_LANG_','retail stores','');
INSERT INTO `_DB_PREFIX_ybc_widget_widget_lang` VALUES('44','_ID_LANG_','New watches','');
INSERT INTO `_DB_PREFIX_ybc_widget_widget_lang` VALUES('45','_ID_LANG_','women’s accessories','');
INSERT INTO `_DB_PREFIX_ybc_widget_widget_lang` VALUES('46','_ID_LANG_','banner left','');


