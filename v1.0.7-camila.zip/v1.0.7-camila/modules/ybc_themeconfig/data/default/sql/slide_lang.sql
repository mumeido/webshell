INSERT INTO `_DB_PREFIX_ybcnivoslider_slides_lang` VALUES('1','_ID_LANG_','New arrivals','<h3>big sale</h3>
<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit<br /> odio. Praesent libero. Sed cursus ante dapibus dia</p>','Men’s fashion','Purchase now','#','308b17a5119e4e4229d7ac925f1b9e01b62928a6_slider-1-a.jpg');
INSERT INTO `_DB_PREFIX_ybcnivoslider_slides_lang` VALUES('7','_ID_LANG_','Women’s accesories','<h3>25% off</h3>
<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit<br /> odio. Praesent libero. Sed cursus ante dapibus dia</p>','new jewellery','Purchase now','#','98b30560cb588597e82af4b92da5f928d7ff25a3_1-2.jpg');


