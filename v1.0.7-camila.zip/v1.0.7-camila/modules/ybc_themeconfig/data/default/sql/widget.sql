INSERT INTO `_DB_PREFIX_ybc_widget_widget` VALUES('14','displayHome','1','0','1','1','wg-home1.jpg','','#','1');
INSERT INTO `_DB_PREFIX_ybc_widget_widget` VALUES('19','ybcCustom3','1','1','1','1','wg-1.jpg','','#','1');
INSERT INTO `_DB_PREFIX_ybc_widget_widget` VALUES('21','ybcCustom5','1','1','1','1','','fa-recycle','','1');
INSERT INTO `_DB_PREFIX_ybc_widget_widget` VALUES('22','ybcCustom5','1','1','1','1','','fa-headphones','','2');
INSERT INTO `_DB_PREFIX_ybc_widget_widget` VALUES('23','ybcCustom5','1','1','1','1','','fa-refresh','','3');
INSERT INTO `_DB_PREFIX_ybc_widget_widget` VALUES('35','ybcCustom3','1','1','1','1','wg2.jpg','','#','2');
INSERT INTO `_DB_PREFIX_ybc_widget_widget` VALUES('36','ybcCustom3','1','1','1','1','wg3.jpg','','#','3');
INSERT INTO `_DB_PREFIX_ybc_widget_widget` VALUES('46','displayLeftColumn','1','0','1','1','ad-banner.jpg','','#','1');


