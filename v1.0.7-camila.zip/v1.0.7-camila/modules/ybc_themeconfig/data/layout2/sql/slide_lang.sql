INSERT INTO `_DB_PREFIX_ybcnivoslider_slides_lang` VALUES('4','_ID_LANG_','New arrivals','<h4>hot deal</h4>
<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit<br /> odio. Praesent libero. Sed cursus ante dapibus dia</p>','Women’s charm','Purchase now','#','eeb865133f1386fdcaed0d88e570aa2639c7aa52_slider-2.jpg');
INSERT INTO `_DB_PREFIX_ybcnivoslider_slides_lang` VALUES('6','_ID_LANG_','New arrivals','<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit<br />odio. Praesent libero. Sed cursus ante dapibus dia</p>','Winter trends','Purchase now','#','13ad6ebc5735cfbc0e90fc84b4e5dfefee0de5dd_2-2.jpg');


