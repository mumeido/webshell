INSERT INTO `_DB_PREFIX_ybc_widget_widget_lang` VALUES('37','_ID_LANG_','Bags and shoes','');
INSERT INTO `_DB_PREFIX_ybc_widget_widget_lang` VALUES('38','_ID_LANG_','Handbag','');
INSERT INTO `_DB_PREFIX_ybc_widget_widget_lang` VALUES('39','_ID_LANG_','Glasses','');
INSERT INTO `_DB_PREFIX_ybc_widget_widget_lang` VALUES('40','_ID_LANG_','Watches','');
INSERT INTO `_DB_PREFIX_ybc_widget_widget_lang` VALUES('41','_ID_LANG_','Accessories','');
INSERT INTO `_DB_PREFIX_ybc_widget_widget_lang` VALUES('42','_ID_LANG_','T-shirts','');


