INSERT INTO `_DB_PREFIX_ybc_widget_widget` VALUES('37','displayTopColumn','1','1','1','1','top1.jpg','','http://theme.yourbestcode.com/camila/en/4-footware','1');
INSERT INTO `_DB_PREFIX_ybc_widget_widget` VALUES('38','displayTopColumn','1','1','1','1','top2.jpg','','http://theme.yourbestcode.com/camila/en/6-handbag','2');
INSERT INTO `_DB_PREFIX_ybc_widget_widget` VALUES('39','displayTopColumn','1','1','1','1','top3.jpg','','http://theme.yourbestcode.com/camila/en/11-glasses','3');
INSERT INTO `_DB_PREFIX_ybc_widget_widget` VALUES('40','displayTopColumn','1','1','1','1','top4.jpg','','http://theme.yourbestcode.com/camila/en/7-watches','4');
INSERT INTO `_DB_PREFIX_ybc_widget_widget` VALUES('41','displayHome','1','1','1','1','home2.jpg','','http://demo.etssoft.net/boom/en/10-accessories','2');
INSERT INTO `_DB_PREFIX_ybc_widget_widget` VALUES('42','displayHome','1','1','1','1','home1s.jpg','','http://theme.yourbestcode.com/camila/en/5-tshirts','1');


