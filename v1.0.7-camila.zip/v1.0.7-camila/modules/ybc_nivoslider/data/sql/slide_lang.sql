INSERT INTO `_DB_PREFIX_ybcnivoslider_slides_lang` VALUES('2','_ID_LANG_','New arrivals','','premium prestashop theme','Purchase now','#','b980620c1262b8d239264987be5779c261b6bb41_fashion-couple.jpg');
INSERT INTO `_DB_PREFIX_ybcnivoslider_slides_lang` VALUES('8','_ID_LANG_','Discover news','','Spring 2017 trends','Purchase now','#','eff582160c77e790f39bd047faecefb07bc2aa0f_fashion-girl.jpg');


