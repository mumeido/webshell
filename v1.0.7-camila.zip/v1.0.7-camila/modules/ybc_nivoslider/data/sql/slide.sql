INSERT INTO `_DB_PREFIX_ybcnivoslider` VALUES('2','1');
INSERT INTO `_DB_PREFIX_ybcnivoslider` VALUES('8','1');


INSERT INTO `_DB_PREFIX_ybcnivoslider_slides` VALUES('2','0','1','random','7%','10%','10%','type4','center','center','60%','','#');
INSERT INTO `_DB_PREFIX_ybcnivoslider_slides` VALUES('8','0','1','random','7%','5%','10%','type1','left','center','55%','','#');


