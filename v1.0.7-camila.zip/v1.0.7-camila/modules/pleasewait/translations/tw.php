<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{pleasewait}prestashop>pleasewait_0b171b59d90e2a5595bae5ae075d8bd1'] = '請稍候...！';
$_MODULE['<{pleasewait}prestashop>pleasewait_6e5a2ae4d41d81d1439888aafed7faf5'] = '在加載您的網站時顯示加載圖標';
$_MODULE['<{pleasewait}prestashop>pleasewait_92328ef0a137839f00cf029c11501175'] = '啟用加載圖標';
$_MODULE['<{pleasewait}prestashop>pleasewait_6d6c669b98589d5cd2abea03d3cea936'] = '正在加載圖標類型';
$_MODULE['<{pleasewait}prestashop>pleasewait_7cc92687130ea12abb80556681538001'] = '圖片上傳過程中出錯。';
$_MODULE['<{pleasewait}prestashop>form_9f5eba7179014f3c071cba0c406523fc'] = '查看所有加載圖標類型';
